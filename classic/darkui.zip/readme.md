# Project Description

Thank you for downloading this texture pack. If you need support or want to join the community, check out my discord: https://discord.gg/aquadevelopment.

## Authors

- ItsAlexHimself_

## Installation & Documentation

To install, simply download the pack.

It is a simple drag & drop into your minecraft resourcepacks folder. The path should be as follows: C:\Users\YOURUSER\AppData\Roaming\.minecraft\resourcepacks.

## Copyright

This is a free-to-use product and can be used anywhere, although this cannot be resold & must be given credit if you plan on using the textures in your own texture pack.